int wynik;
    // char znak;