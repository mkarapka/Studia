#include<stdio.h>
int main(){
    char napis;
    if (scanf("%c" , &napis)!=0)
    {
        printf("\n%c\n" , napis);
    }
    
    
    return 0;
}