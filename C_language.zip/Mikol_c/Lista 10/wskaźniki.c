#include<stdio.h>
int main(){
    int *fp;
    int cos = 3;
    *fp = cos;
    printf("%d" , *fp);
    return 0;
}