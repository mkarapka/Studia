from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Opis tego, co robi to polecenie."

    def handle(self, *args, **kwargs):
        self.stdout.write(
            """
add_book - Dodaje książkę do biblioteki
add_friend - Dodaje znajomego do biblioteki
borrow - Wypożycza książkę znajomemu
listbooks - Wyświetla listę wszystkich książek wraz z ich ID
listborrows - Wyświetla listę wszystkich wypożyczeń wraz z ich ID
listfriends - Wyświetla listę wszystkich znajomych wraz z ich ID
remove_book - Usuwa książkę z biblioteki
return - Oznacza książkę jako zwróconą
    """
        )
