#include <iostream>
#include <cmath>

using namespace std;

double f_double(double x)  {
    return 14 * ((1 - cos(17 * x)) / pow(x, 2));
}

float f_single(float x)  {
    return 14 * ((1 - cos(17 * x)) / pow(x, 2));
}

int main()  {
    for(int i = 0; i >= -20; i--)   {
        cout<<"Dla x = 10^"<<i<<" :"<<endl;
        cout<<"Pojedyncza precyzja: "<<f_single(pow(10,i))<<endl
            <<"Podwojna precyzja: "<<f_double(pow(10,i))<<endl;
    }
}