#pragma once
#include<cmath>
#include<iostream>
#include<string>
namespace kalkulator{
    class Funkcja : public Symbol{
        public:
            virtual double calculate(double val1, double val2 = 0) = 0;
            virtual bool isUnary() = 0;
    };

    class Add : public Funkcja{
        public:
            double value;

            double calculate(double val1, double val2) override {
                value = val1 + val2;
                return value;
            }

            bool isUnary(){
                return false;
            }
    };    

    class Sub : public Funkcja{
        public:
            double value;

            double calculate(double val1, double val2) override { 
                value = val1 - val2;
                return value;
            }

            bool isUnary(){
                return false;
            }
    };

    class Mult : public Funkcja{
        public:
            double value;

            double calculate(double val1, double val2) override{
                value =  val1 * val2;
                return value;
            }

            bool isUnary(){
                return false;
            }
    };

    class Div : public Funkcja{
        public:
            double value;

            double calculate(double val1, double val2) override {
                if (val2 != 0){
                    value = val1 / val2;
                    
                }
                else{
                    throw "Division by zero!";
                }
                return value;
            }

            bool isUnary(){
                return false;
            }
    };

    class Modulo : public Funkcja{
        public:
            double value;

            double calculate(double val1, double val2) override {
                value = fmod(val1, val2);
                return value;
            }

            bool isUnary(){
                return false;
            }
    };
    
    class Min : public Funkcja{
        public:
            double value;

            double calculate(double val1, double val2) override {
                if(val1 < val2){
                    value = val1;
                }

                else{
                    value = val2;
                }
                return value;
            }

            bool isUnary(){
                return false;
            }
    };

    class Max : public Funkcja{
        public:
            double value;

            double calculate(double val1, double val2) override {
                if(val1 > val2){
                    value = val1;
                }

                else{
                    value = val2;
                }
                return value;
            }

            bool isUnary(){
                return false;
            }
    };

    class Pow : public Funkcja{
        public:
            double value;

            double calculate(double val1, double val2) override {
                value = pow(val1, val2);
                return value;
            }

            bool isUnary(){
                return false;
            }
    };

    class Abs : public Funkcja{
        public:
            double value;

            double calculate(double val1,double val2) override {
                value = abs(val1);
                return value;
            }

            bool isUnary(){
                return true;
            }
    };

    class Sng : public Funkcja{
        public:
            double value;

            double calculate(double val1,double val2) override {
                if(val1 > 0){
                    value = 1;
                }
                else if (val1 == 0){
                    value = 0;
                }
                else{
                    value = -1;
                }
                return value;
            }

            bool isUnary(){
                return true;
            }
    };

    class Floor : public Funkcja{
        public:
            double value;

            double calculate(double val1,double val2) override {
                value = floor(val1);
                return value;
            }

            bool isUnary(){
                return true;
            }
    };

    class Ceil : public Funkcja{
        public:
            double value;

            double calculate(double val1,double val2) override {
                value = ceil(val2);
                return value;
            }

            bool isUnary(){
                return true;
            }
    };

    class Frac : public Funkcja{
        public:
            double value;

            double calculate(double val1, double val2) override {
                double result = 1, i = 1,tmp;
                while (i-1 != val1)
                {
                    result *= i;
                    i ++;
                }
                value = result;
                return value;
            }

            bool isUnary(){
                return true;
            }
    };

    class Sin : public Funkcja {
    public:
        double value;

        double calculate(double val1, double val2) override {
            value = sin(val1);
            return value;
        }

        bool isUnary(){
                return true;
            }
    };

    class Cos : public Funkcja {
    public:
        double value;

        double calculate(double val1, double val2) override {
            value = cos(val1);
            return value;

        }

        bool isUnary(){
                return true;
            }
    };

    class Log : public Funkcja {
    public:
        double value;

        double calculate(double val1, double val2) override {
            if (val2 <= 0) {
                throw "Logarithm base must be positive!";
            }
            value = log(val1) / log(val2);
            return value;
        }

        bool isUnary(){
                return false;
            }
    };

    class Exp : public Funkcja {
    public:
        double value;
        
        double calculate(double val1, double val2 = 0) override {
            value = exp(val1);
            return value;
        }

        bool isUnary(){
                return true;
            }
    };
};